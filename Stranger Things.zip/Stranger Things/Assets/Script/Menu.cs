﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Menu : MonoBehaviour
{
    public Canvas MCanvas;
    public Canvas OptionCanvas;

    private void Awake()
    {
        OptionCanvas.enabled = false;
    }

    public void Sleep()
    {
        OptionCanvas.enabled = true;
        MCanvas.enabled = false;
    }

    public void ReturnAwake()
    {
        OptionCanvas.enabled = false;
        MCanvas.enabled = true;
    }

    public void LoadOn()
    {
        Application.LoadLevel(1);
    }
}
